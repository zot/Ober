//--------------------------------------------------------------------------
//	Copyright (c) 2002, Drew Davidson and Luke Blanshard
//  All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are
//  met:
//
//	Redistributions of source code must retain the above copyright notice,
//  this list of conditions and the following disclaimer.
//	Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//	Neither the name of the Drew Davidson nor the names of its contributors
//  may be used to endorse or promote products derived from this software
//  without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
//  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
//  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
//  OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
//  AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
//  THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
//  DAMAGE.
//--------------------------------------------------------------------------
package ognl;

import java.lang.reflect.Array;
import java.util.Map;

/**
 * Implementation of PropertyAccessor that uses numbers and dynamic subscripts as
 * properties to index into Java arrays.
 * @author Luke Blanshard (luke@quiq.com)
 * @author Drew Davidson (drew@ognl.org)
 */
public class ArrayPropertyAccessor extends ObjectPropertyAccessor
    implements PropertyAccessor // This is here to make javadoc show this class as an implementor
{
    public Object getProperty( Map context, Object target, Object name ) throws OgnlException
    {
        if ( name instanceof String )
          {
            if ( name.equals("length") )
                return new Integer( Array.getLength(target) );
            return super.getProperty( context, target, name );
          }

        if ( name instanceof Number )
            return Array.get( target, ((Number)name).intValue() );

        if ( name instanceof DynamicSubscript )
          {
            int len = Array.getLength( target );
            switch ( ((DynamicSubscript)name).getFlag() )
              {
                case DynamicSubscript.FIRST:    return len > 0? Array.get(target,0) : null;
                case DynamicSubscript.MID:      return len > 0? Array.get(target,len/2) : null;
                case DynamicSubscript.LAST:     return len > 0? Array.get(target,len-1) : null;
                case DynamicSubscript.ALL:
                  {
                    Object answer = Array.newInstance( target.getClass().getComponentType(), len );
                    System.arraycopy( target, 0, answer, 0, len );
                    return answer;
                  }
              }
          }

        throw new NoSuchPropertyException( target, name );
    }

    public void setProperty( Map context, Object target, Object name, Object value ) throws OgnlException
    {
        if ( name instanceof String )
          {
            super.setProperty( context, target, name, value );
            return;
          }

        if ( name instanceof Number )
          {
            Array.set( target, ((Number)name).intValue(), value );
            return;
          }

        if ( name instanceof DynamicSubscript )
          {
            int len = Array.getLength( target );
            switch ( ((DynamicSubscript)name).getFlag() )
              {
                case DynamicSubscript.FIRST:    if ( len > 0 ) Array.set(target,0,value);       return;
                case DynamicSubscript.MID:      if ( len > 0 ) Array.set(target,len/2,value);   return;
                case DynamicSubscript.LAST:     if ( len > 0 ) Array.set(target,len-1,value);   return;
                case DynamicSubscript.ALL:      System.arraycopy( target, 0, value, 0, len );   return;
              }
          }

        throw new NoSuchPropertyException( target, name );
    }
}
