//--------------------------------------------------------------------------
//	Copyright (c) 2002, Drew Davidson and Luke Blanshard
//  All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are
//  met:
//
//	Redistributions of source code must retain the above copyright notice,
//  this list of conditions and the following disclaimer.
//	Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//	Neither the name of the Drew Davidson nor the names of its contributors
//  may be used to endorse or promote products derived from this software
//  without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
//  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
//  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
//  OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
//  AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
//  THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
//  DAMAGE.
//--------------------------------------------------------------------------
package ognl;

import java.io.*;
import java.lang.reflect.*;
import java.math.*;
import java.util.*;

/**
 * This is an abstract class with static methods that define the operations of OGNL.
 * @author Luke Blanshard (luke@quiq.com)
 * @author Drew Davidson (drew@ognl.org)
 */
public abstract class OgnlOps implements NumericTypes
{
      /**
       * Evaluates the given object as a boolean: if it is a Boolean object, it's easy; if
       * it is a String, uses the Boolean.valueOf() method (which returns true if the
       * lower-case value of the string is "true"); if it's a Number or a Character,
       * returns true for non-zero objects; and otherwise returns true for non-null
       * objects.
       *
       * @param value an object to interpret as a boolean
       * @return the boolean value implied by the given object
       */
    public static boolean booleanValue( Object value )
    {
        if ( value == null )
            return false;
        Class c = value.getClass();
        if ( c == Boolean.class )
            return ((Boolean)value).booleanValue();
        if ( c == String.class )
            return Boolean.valueOf((String)value).booleanValue();
        if ( c == Character.class )
            return ((Character)value).charValue() != 0;
        if ( value instanceof Number )
            return ((Number)value).doubleValue() != 0;
        return true; // non-null
    }

      /**
       * Evaluates the given object as a long integer.
       *
       * @param value an object to interpret as a long integer
       * @return the long integer value implied by the given object
       * @throws NumberFormatException if the given object can't be understood as a long integer
       */
    public static long longValue( Object value )
    {
        Class c = value.getClass();
        if ( c.getSuperclass() == Number.class )
            return ((Number)value).longValue();
        if ( c == Character.class )
            return ((Character)value).charValue();
        if ( c == Boolean.class )
            return ((Boolean)value).booleanValue()? 1 : 0;
        return Long.parseLong( value.toString() );
    }

      /**
       * Evaluates the given object as a double-precision floating-point number.
       *
       * @param value an object to interpret as a double
       * @return the double value implied by the given object
       * @throws NumberFormatException if the given object can't be understood as a double
       */
    public static double doubleValue( Object value )
    {
        Class c = value.getClass();
        if ( c.getSuperclass() == Number.class )
            return ((Number)value).doubleValue();
        if ( c == Character.class )
            return ((Character)value).charValue();
        if ( c == Boolean.class )
            return ((Boolean)value).booleanValue()? 1 : 0;
        return Double.parseDouble( value.toString() );
        /*
            For 1.1 parseDouble() is not available
         */
        //return Double.valueOf( value.toString() ).doubleValue();
    }

      /**
       * Evaluates the given object as a BigInteger.
       *
       * @param value an object to interpret as a BigInteger
       * @return the BigInteger value implied by the given object
       * @throws NumberFormatException if the given object can't be understood as a BigInteger
       */
    public static BigInteger bigIntValue( Object value )
    {
        Class c = value.getClass();
        if ( c == BigInteger.class )
            return (BigInteger)value;
        if ( c == BigDecimal.class )
            return ((BigDecimal)value).toBigInteger();
        if ( c.getSuperclass() == Number.class )
            return BigInteger.valueOf( ((Number)value).longValue() );
        if ( c == Character.class )
            return BigInteger.valueOf( ((Character)value).charValue() );
        if ( c == Boolean.class )
            return BigInteger.valueOf( ((Boolean)value).booleanValue()? 1 : 0 );
        return new BigInteger( value.toString() );
    }

      /**
       * Evaluates the given object as a BigDecimal.
       *
       * @param value an object to interpret as a BigDecimal
       * @return the BigDecimal value implied by the given object
       * @throws NumberFormatException if the given object can't be understood as a BigDecimal
       */
    public static BigDecimal bigDecValue( Object value )
    {
        Class c = value.getClass();
        if ( c == BigDecimal.class )
            return (BigDecimal)value;
        if ( c == BigInteger.class )
            return new BigDecimal( (BigInteger)value );
        if ( c.getSuperclass() == Number.class )
            return new BigDecimal( ((Number)value).doubleValue() );
        if ( c == Character.class )
            return BigDecimal.valueOf( ((Character)value).charValue() );
        if ( c == Boolean.class )
            return BigDecimal.valueOf( ((Boolean)value).booleanValue()? 1 : 0 );
        return new BigDecimal( value.toString() );
    }

      /**
       * Returns a constant from the NumericTypes interface that represents the numeric
       * type of the given object.
       *
       * @param value an object that needs to be interpreted as a number
       * @return the appropriate constant from the NumericTypes interface
       */
    public static int getNumericType( Object value )
    {
        Class c = value.getClass();
        if ( c == Integer.class )       return INT;
        if ( c == Double.class )        return DOUBLE;
        if ( c == Boolean.class )       return BOOL;
        if ( c == Byte.class )          return BYTE;
        if ( c == Character.class )     return CHAR;
        if ( c == Short.class )         return SHORT;
        if ( c == Long.class )          return LONG;
        if ( c == Float.class )         return FLOAT;
        if ( c == BigInteger.class )    return BIGINT;
        if ( c == BigDecimal.class )    return BIGDEC;
        return NONNUMERIC;
    }

    /**
       * Returns the value converted numerically to the given class type
       *
       * @param value an object to be converted to the given type
       * @param toType class type to be converted to
       * @return converted value of the type given, or value if the value
       *                cannot be converted to the given type.
     */
    public static Object convertValue( Object value, Class toType)
    {
        Object  result = null;

        if (value != null) {
            if ( ( toType == Integer.class ) || ( toType == Integer.TYPE ) )        result = new Integer((int)longValue(value));
            if ( ( toType == Double.class ) || ( toType == Double.TYPE ) )          result = new Double(doubleValue(value));
            if ( ( toType == Boolean.class ) || ( toType == Boolean.TYPE ) )        result = booleanValue(value) ? Boolean.TRUE : Boolean.FALSE;
            if ( ( toType == Byte.class ) || ( toType == Byte.TYPE ) )              result = new Byte((byte)longValue(value));
            if ( ( toType == Character.class ) || ( toType == Character.TYPE ) )    result = new Character((char)longValue(value));
            if ( ( toType == Short.class ) || ( toType == Short.TYPE ) )            result = new Short((short)longValue(value));
            if ( ( toType == Long.class ) || ( toType == Long.TYPE ) )              result = new Long(longValue(value));
            if ( ( toType == Float.class ) || ( toType == Float.TYPE ) )            result = new Float(doubleValue(value));
            if ( toType == BigInteger.class )                                       result = bigIntValue(value);
            if ( toType == BigDecimal.class )                                       result = bigDecValue(value);
            if ( toType == String.class )                                           result = value.toString();
        }
        return result;
    }

      /**
       * Returns the constant from the NumericTypes interface that best expresses the type
       * of a numeric operation on the two given objects.
       *
       * @param v1 one argument to a numeric operator
       * @param v2 the other argument
       * @return the appropriate constant from the NumericTypes interface
       */
    public static int getNumericType( Object v1, Object v2 )
    {
        return getNumericType( v1, v2, false );
    }

      /**
       * Returns the constant from the NumericTypes interface that best expresses the type
       * of an operation, which can be either numeric or not, on the two given objects.
       *
       * @param v1 one argument to an operator
       * @param v2 the other argument
       * @param canBeNonNumeric whether the operator can be interpreted as non-numeric
       * @return the appropriate constant from the NumericTypes interface
       */
    public static int getNumericType( Object v1, Object v2, boolean canBeNonNumeric )
    {
        int t1 = getNumericType(v1), t2 = getNumericType(v2);
        if ( t1 == t2 )
            return t1;

        if ( canBeNonNumeric && (t1 == NONNUMERIC || t2 == NONNUMERIC || t1 == CHAR || t2 == CHAR) )
            return NONNUMERIC;

        if ( t1 == NONNUMERIC ) t1 = DOUBLE;    // Try to interpret strings as doubles...
        if ( t2 == NONNUMERIC ) t2 = DOUBLE;    // Try to interpret strings as doubles...

        if ( t1 >= MIN_REAL_TYPE )
          {
            if ( t2 >= MIN_REAL_TYPE )
                return Math.max(t1,t2);
            if ( t2 < INT )
                return t1;
            if ( t2 == BIGINT )
                return BIGDEC;
            return Math.max(DOUBLE,t1);
          }
        else if ( t2 >= MIN_REAL_TYPE )
          {
            if ( t1 < INT )
                return t2;
            if ( t1 == BIGINT )
                return BIGDEC;
            return Math.max(DOUBLE,t2);
          }
        else
            return Math.max(t1,t2);
    }

      /**
       * Returns a new Number object of an appropriate type to hold the given integer
       * value.  The type of the returned object is consistent with the given type
       * argument, which is a constant from the NumericTypes interface.
       *
       * @param type    the nominal numeric type of the result, a constant from the NumericTypes interface
       * @param value   the integer value to convert to a Number object
       * @return        a Number object with the given value, of type implied by the type argument
       */
    public static Number newInteger( int type, long value )
    {
        switch ( type )
          {
            case BOOL: case CHAR: case INT:
                return new Integer( (int)value );
            case FLOAT:
                if ( (long)(float)value == value )
                    return new Float( (float)value );
                // else fall through:
            case DOUBLE:
                if ( (long)(double)value == value )
                    return new Double( (double)value );
                // else fall through:
            case LONG:
                return new Long( value );
            case BYTE:
                return new Byte( (byte)value );
            case SHORT:
                return new Short( (short)value );
            default:
                return BigInteger.valueOf( value );
          }
    }

      /**
       * Returns a new Number object of an appropriate type to hold the given real value.
       * The type of the returned object is always either Float or Double, and is only
       * Float if the given type tag (a constant from the NumericTypes interface) is
       * FLOAT.
       *
       * @param type    the nominal numeric type of the result, a constant from the NumericTypes interface
       * @param value   the real value to convert to a Number object
       * @return        a Number object with the given value, of type implied by the type argument
       */
    public static Number newReal( int type, double value )
    {
        if ( type == FLOAT )
            return new Float( (float)value );
        return new Double( value );
    }

    public static Object binaryOr( Object v1, Object v2 )
    {
        int type = getNumericType(v1,v2);
        if ( type == BIGINT || type == BIGDEC )
            return bigIntValue(v1).or(bigIntValue(v2));
        return newInteger( type, longValue(v1) | longValue(v2) );
    }

    public static Object binaryXor( Object v1, Object v2 )
    {
        int type = getNumericType(v1,v2);
        if ( type == BIGINT || type == BIGDEC )
            return bigIntValue(v1).xor(bigIntValue(v2));
        return newInteger( type, longValue(v1) ^ longValue(v2) );
    }

    public static Object binaryAnd( Object v1, Object v2 )
    {
        int type = getNumericType(v1,v2);
        if ( type == BIGINT || type == BIGDEC )
            return bigIntValue(v1).and(bigIntValue(v2));
        return newInteger( type, longValue(v1) & longValue(v2) );
    }

    public static boolean equal( Object v1, Object v2 )
    {
        if ( v1 == null )
            return v2 == null;
        if ( v1 == v2 || v1.equals(v2) )
            return true;
        if ( v1 instanceof Number && v2 instanceof Number )
            return ((Number)v1).doubleValue() == ((Number)v2).doubleValue();
        return false;
    }

    public static boolean less( Object v1, Object v2 )
    {
        int type = getNumericType(v1,v2,true);
        switch ( type )
          {
            case BIGINT:    return bigIntValue(v1).compareTo(bigIntValue(v2)) < 0;
            case BIGDEC:    return bigDecValue(v1).compareTo(bigDecValue(v2)) < 0;
            case NONNUMERIC:
                if ( v1 instanceof Comparable )
                    return ((Comparable)v1).compareTo(v2) < 0;
                // else fall through
            case FLOAT:
            case DOUBLE:    return doubleValue(v1) < doubleValue(v2);
            default:        return longValue(v1) < longValue(v2);
          }
    }

    public static boolean greater( Object v1, Object v2 )
    {
        int type = getNumericType(v1,v2,true);
        switch ( type )
          {
            case BIGINT:    return bigIntValue(v1).compareTo(bigIntValue(v2)) > 0;
            case BIGDEC:    return bigDecValue(v1).compareTo(bigDecValue(v2)) > 0;
            case NONNUMERIC:
                if ( v1 instanceof Comparable )
                    return ((Comparable)v1).compareTo(v2) < 0;
                // else fall through
            case FLOAT:
            case DOUBLE:    return doubleValue(v1) > doubleValue(v2);
            default:        return longValue(v1) > longValue(v2);
          }
    }

    public static boolean in( Object v1, Object v2 ) throws OgnlException
    {
        if ( v2 == null )   // A null collection is always treated as empty
            return false;

        ElementsAccessor e = OgnlRuntime.getElementsAccessor(v2.getClass());
        for ( Enumeration enum=e.getElements(v2); enum.hasMoreElements(); )
          {
            Object o = enum.nextElement();
            if ( equal(v1,o) )
                return true;
          }
        return false;
    }

    public static Object shiftLeft( Object v1, Object v2 )
    {
        int type = getNumericType(v1);
        if ( type == BIGINT || type == BIGDEC )
            return bigIntValue(v1).shiftLeft( (int)longValue(v2) );
        return newInteger( type, longValue(v1) << (int)longValue(v2) );
    }

    public static Object shiftRight( Object v1, Object v2 )
    {
        int type = getNumericType(v1);
        if ( type == BIGINT || type == BIGDEC )
            return bigIntValue(v1).shiftRight( (int)longValue(v2) );
        return newInteger( type, longValue(v1) >> (int)longValue(v2) );
    }

    public static Object unsignedShiftRight( Object v1, Object v2 )
    {
        int type = getNumericType(v1);
        if ( type == BIGINT || type == BIGDEC )
            return bigIntValue(v1).shiftRight( (int)longValue(v2) );
        if ( type <= INT )
            return newInteger( INT, ((int)longValue(v1)) >>> (int)longValue(v2) );
        return newInteger( type, longValue(v1) >>> (int)longValue(v2) );
    }

    public static Object add( Object v1, Object v2 )
    {
        int type = getNumericType(v1,v2,true);
        switch ( type )
          {
            case BIGINT:    return bigIntValue(v1).add(bigIntValue(v2));
            case BIGDEC:    return bigDecValue(v1).add(bigDecValue(v2));
            case FLOAT:
            case DOUBLE:    return newReal( type, doubleValue(v1) + doubleValue(v2) );
            case NONNUMERIC:return v1.toString() + v2.toString();
            default:        return newInteger( type, longValue(v1) + longValue(v2) );
          }
    }

    public static Object subtract( Object v1, Object v2 )
    {
        int type = getNumericType(v1,v2);
        switch ( type )
          {
            case BIGINT:    return bigIntValue(v1).subtract(bigIntValue(v2));
            case BIGDEC:    return bigDecValue(v1).subtract(bigDecValue(v2));
            case FLOAT:
            case DOUBLE:    return newReal( type, doubleValue(v1) - doubleValue(v2) );
            default:        return newInteger( type, longValue(v1) - longValue(v2) );
          }
    }

    public static Object multiply( Object v1, Object v2 )
    {
        int type = getNumericType(v1,v2);
        switch ( type )
          {
            case BIGINT:    return bigIntValue(v1).multiply(bigIntValue(v2));
            case BIGDEC:    return bigDecValue(v1).multiply(bigDecValue(v2));
            case FLOAT:
            case DOUBLE:    return newReal( type, doubleValue(v1) * doubleValue(v2) );
            default:        return newInteger( type, longValue(v1) * longValue(v2) );
          }
    }

    public static Object divide( Object v1, Object v2 )
    {
        int type = getNumericType(v1,v2);
        switch ( type )
          {
            case BIGINT:    return bigIntValue(v1).divide(bigIntValue(v2));
            case BIGDEC:    return bigDecValue(v1).divide( bigDecValue(v2), BigDecimal.ROUND_HALF_EVEN );
            case FLOAT:
            case DOUBLE:    return newReal( type, doubleValue(v1) / doubleValue(v2) );
            default:        return newInteger( type, longValue(v1) / longValue(v2) );
          }
    }

    public static Object remainder( Object v1, Object v2 )
    {
        int type = getNumericType(v1,v2);
        switch ( type )
          {
            case BIGDEC:
            case BIGINT:    return bigIntValue(v1).remainder(bigIntValue(v2));
            default:        return newInteger( type, longValue(v1) % longValue(v2) );
          }
    }

    public static Object negate( Object value )
    {
        int type = getNumericType(value);
        switch ( type )
          {
            case BIGINT:    return bigIntValue(value).negate();
            case BIGDEC:    return bigDecValue(value).negate();
            case FLOAT:
            case DOUBLE:    return newReal( type, -doubleValue(value) );
            default:        return newInteger( type, -longValue(value) );
          }
    }

    public static Object bitNegate( Object value )
    {
        int type = getNumericType(value);
        switch ( type )
          {
            case BIGDEC:
            case BIGINT:    return bigIntValue(value).not();
            default:        return newInteger( type, ~longValue(value) );
          }
    }
}
